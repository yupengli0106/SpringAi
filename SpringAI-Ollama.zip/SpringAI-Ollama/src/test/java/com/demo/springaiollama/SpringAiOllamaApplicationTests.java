package com.demo.springaiollama;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiOllamaApplicationTests {

	@Test
	void contextLoads() {
	}

}
