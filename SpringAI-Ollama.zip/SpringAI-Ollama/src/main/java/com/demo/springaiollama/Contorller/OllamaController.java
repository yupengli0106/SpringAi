package com.demo.springaiollama.Contorller;

import jakarta.annotation.Resource;
import org.springframework.ai.ollama.OllamaChatClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: Yupeng Li
 * @Date: 11/5/2024 15:23
 * @Description:
 */
@RestController
public class OllamaController {

    @Resource
    private OllamaChatClient ollamaChatClient;

    @RequestMapping("/ollama")
    public String ollama(@RequestParam("msg") String message) {
        String response = ollamaChatClient.call(message);
        return response;
    }

}
